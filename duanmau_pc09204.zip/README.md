Chạy lệnh: php -S <cổng>. Ví dụ: php -S 127.0.0.1:8080
- Truy cập client: Trang index: 127.0.0.1:8080, trang test: 127.0.0.1:8080/
- Truy cập admin: Trang index: 127.0.0.1:8080/admin, trang test: 127.0.0.1:8080/admin/test